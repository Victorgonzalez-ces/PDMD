package com.example.victor_gonzalez_dam2.model

import java.io.Serializable

class Restaurante(var nombre: String, var localizacion: String, var puntuacion: Int, var comida: String, var telefono: Int): Serializable {
}