package com.example.victor_gonzalez_dam2

class SecondActivity {
}